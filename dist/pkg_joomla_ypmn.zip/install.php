<?php
/**
 * @package    Your payments
 *
 * @copyright  Copyright (C) 2025  Your payments. All rights reserved.
 * @author     Your payments <info@ypmn.ru>
 * 			   20.07.25
 *
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\Folder;

defined('_JEXEC') or die;
class pkg_ypmnInstallerScript
{
	public function install($parent)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query->update('#__extensions');
		$query->set($db->quoteName('enabled') . ' = 1');
		$query->where($db->quoteName('element') . ' = ' . $db->quote('jshopping_ypmn'));
		$query->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
		$db->setQuery($query);
		$db->execute();

		if (!Folder::exists(JPATH_ROOT . '/components/com_jshopping/payments')) {
			return true;
		}

		Folder::move(dirname(__FILE__) . '/pm_ypmn', JPATH_ROOT . '/components/com_jshopping/payments/pm_ypmn');
		$pm = [
			'payment_code'        => 'ypmn',
			'payment_class'       => 'pm_ypmn',
			'scriptname'          => 'pm_ypmn',
			'payment_publish'     => 0,
			'payment_type'        => 2,
			'price'               => 0.0,
			'price_type'          => 0,
			'show_descr_in_email' => 0,
			'name_ru-RU'          => 'Твои платежи',
			'name_en-GB'          => 'Твои платежи',
			'name_de-DE'          => 'Твои платежи',
			'payment_params'      => '{}',
			'order_description'   => '',
			'description_en-GB'   => '',
			'description_ru-RU'   => '',
			'description_de-DE'   => '',

		];
		$pm     = (object) $pm;
		$result = Factory::getDbo()->insertObject('#__jshopping_payment_method', $pm);

	}
	public function postflight($type, $parent=null)
	{

		if ($type == 'update') {
			Folder::delete(JPATH_ROOT . '/components/com_jshopping/payments/pm_ypmn');
			Folder::move(dirname(__FILE__) . '/pm_ypmn', JPATH_ROOT . '/components/com_jshopping/payments/pm_ypmn');
		}

		return true;
	}

	public function uninstall($x)
	{
		$db    = Factory::getDBO();
		$query = $db->getQuery(true);

		$conditions = array(
			$db->quoteName('payment_class') . ' = "pm_ypmn"',
		);

		$query->delete($db->quoteName('#__jshopping_payment_method'));
		$query->where($conditions);

		$db->setQuery($query);

		try {
			$result = $db->execute();
		} catch (\Exception $e) {}


		$modulePath = JPATH_ROOT . '/components/com_jshopping/payments/pm_ypmn';
		if (Folder::exists($modulePath)) {
			Folder::delete($modulePath);
		}

	}

}
