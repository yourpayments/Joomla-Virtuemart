<?php
/**
 * @package    Your payments
 *
 * @copyright  Copyright (C) 2025  Your payments. All rights reserved.
 * @author     Your payments <info@ypmn.ru>
 *             20.07.25
 *
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');?>
<script type="text/javascript">
function check_pm_ypmn(){
    $_('payment_form').submit();
}
</script>