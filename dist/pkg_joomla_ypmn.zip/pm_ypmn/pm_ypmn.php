<?php
/**
 * @package    Your payments
 *
 * @copyright  Copyright (C) 2025  Your payments. All rights reserved.
 * @author     Your payments <info@ypmn.ru>
 * 			   20.07.25
 *
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');
include_once JPATH_ADMINISTRATOR . '/components/com_ypmn/helper/helper.php';


use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

use Ypmn\Authorization;
use Ypmn\Payment;
use Ypmn\Client;
use Ypmn\Billing;
use Ypmn\ApiRequest;
use Ypmn\Product;
use Ypmn\PaymentMethods;


class pm_ypmn extends PaymentRoot
{

	private $config = null;
	private $pmconfigs = null;
	private $logger      = null;

	public function showPaymentForm($params, $pmconfigs)
	{
		include dirname(__FILE__) . "/paymentform.php";
	}

	//function call in admin
	public function showAdminFormParams($params)
	{
		$lang = Factory::getLanguage();
		$extension = 'com_ypmn';
		$lang->load($extension);

		if ($params == "") {
			$params = [];
		}

		$settings = array(
			'transaction_end_status'     => 6, //Paid
			'transaction_confirm_status'     => 6, //Paid
			'transaction_refunded_status'     => 4, //Paid
			'transaction_pending_status' => 1, //Pending
		);
		foreach ($settings as $key => $value) {
			if (!isset($params[$key])) {
				$params[$key] = $value;
			}

		}
		$orders = Joomla\CMS\MVC\Model\BaseDatabaseModel::getInstance('orders', 'JshoppingModel'); //admin model
		include dirname(__FILE__) . "/adminparamsform.php";
	}

	public function checkTransaction($pmconfigs, $order, $act)
	{
		$this->config = ComponentHelper::getParams('com_ypmn');
		$this->logger = YpmnHelper::getLogger();


		$data     = file_get_contents("php://input");
		$this->logger->info($data, ['category' => 'com_ypmn_callback']);
		$headerSignature = $_SERVER['HTTP_X_HEADER_SIGNATURE'] ?? '';
		$signature =  YpmnHelper::calcSignature($data);

		if (strcasecmp($headerSignature, $signature) !== 0 ) {
			throw new \Exception('Sign error');
		}

		$json = json_decode($data, true);
		$orderData =  $json['orderData'];

		$responseData = YpmnHelper::getTransactionInfo($orderData['merchantPaymentReference']);
		$this->logger->info(json_encode($responseData), ['category' => 'com_ypmn_status_result']);
		if ($responseData['code'] !== 200) {
			throw new \Exception($responseData["message"]);
		}
		$res = explode('.', $orderData['merchantPaymentReference']);

		$merchantPaymentReference = sprintf("%s.%s", $res[0], $res[1]);

		$transaction = [
			'payment_status' => $responseData['paymentStatus'],
			'merchant_payment_reference' => $merchantPaymentReference,
			'merchant_payment_reference_active' => $orderData['merchantPaymentReference'],
			'payu_payment_reference' => $orderData['payuPaymentReference'],
		];

		YpmnHelper::updateTransaction($transaction, 'com_jshopping');

		if (in_array($responseData['paymentStatus'], ['PAYMENT_AUTHORIZED'])) {
			return [8, ''];
		}
		if (in_array($responseData['paymentStatus'], ['COMPLETE'])) {
			return [1, ''];
		}

		if (
			in_array($responseData['paymentStatus'], ['REFUND', 'REVERSED'])
		) {
			return [7, ''];
		}

		return [0, ''];
	}

	public function showEndForm($pmconfigs, $order)
	{
		$lang = Factory::getLanguage();
		$extension = 'com_ypmn';
		$lang->load($extension);
		$this->pmconfigs = $pmconfigs;
		$this->config        = ComponentHelper::getParams('com_ypmn');
		$this->logger = YpmnHelper::getLogger();

		if ($order->currency_code_iso != 'RUB') {
			$session = Factory::getSession();
			$session->set('jshop_send_end_form', 0);
			$app = Factory::getApplication();
			$app->enqueueMessage(Text::_('COM_YPMN_JSHOP_CURRENCY_ERROR'), 'error');
			$app->redirect(Route::_('index.php?option=com_jshopping&controller=checkout&task=step3'));
			return false;
		}

		$amount = $order->order_total;

		try{
			$ypmnPayment = $this->createPayment($order, $amount);
			$this->logger->info($ypmnPayment->jsonSerialize(), ['category' => 'com_ypmn_payment']);
		} catch(\Exception $e) {
			$app = Factory::getApplication();
			$app->enqueueMessage($e->getMessage(), 'error');
			$app->redirect(Route::_('index.php?option=com_jshopping&controller=checkout&task=step3'));
		}
		$apiRequest      = YpmnHelper::getApi();
		$responseDataRaw = $apiRequest->sendAuthRequest($ypmnPayment);
		$responseData = json_decode((string) $responseDataRaw["response"], true);
		$this->logger->info(json_encode($responseDataRaw), ['category' => 'com_ypmn_payment_result']);
		if (isset($responseData['code']) && $responseData['code'] != 200) {
			$app = Factory::getApplication();
			$app->enqueueMessage($responseData['message'], 'error');
			$app->redirect(Route::_('index.php?option=com_jshopping&controller=checkout&task=step3'));
		}


		$transaction = [
			'order_number'               => $order->order_number,
			'order_id'                   => $order->order_id,
			'merchant_payment_reference' => $responseData['merchantPaymentReference'],
			'merchant_payment_reference_active' => $responseData['merchantPaymentReference'],
			'url'                        => $responseData["paymentResult"]['url'],
			'payment_status'             => $responseData['paymentResult']['payuResponseCode'],
			'payment_method'             => $this->config->get('payment_method'),
			'amount'                     => $responseData['amount'],
			'products'                   => json_encode($ypmnPayment->getProductsArray()),
			'merchant_payment_reference_active' => $responseData['merchantPaymentReference'],
		];

		if ($responseData['payuPaymentReference'] !== 'NOT_YET_REGISTERED') {
			$transaction['payu_payment_reference'] = $responseData['payuPaymentReference'];
		}

		YpmnHelper::insertJsTransaction($transaction);


		$html = Text::_('COM_YPMN_REDIRECT_MESSAGE');

		$order->order_created = 1;
		$order->order_status  = $pmconfigs['transaction_pending_status'];
		$order->store();
		Factory::getApplication()->redirect($responseData["paymentResult"]['url']);
		die();
	}


	private function createPayment($order)
	{
		$ypmnPayment = new Payment();
		$ypmnPayment->setCurrency('RUB');
		$products = $this->getOrderProducts($order);
		foreach ($products as $product) {
			$ypmnPayment->addProduct($product);
		}
		$merchantPaymentReference = sprintf("%s.%s", $order->order_id, time());
		$ypmnPayment->setMerchantPaymentReference($merchantPaymentReference);
		$ypmnPayment->setReturnUrl($this->getReturnUrl($order));

		$client = $this->getClient($order);
		$ypmnPayment->setClient($client);

		$authorization = $this->getAuthorization();
		$ypmnPayment->setAuthorization($authorization);
		return $ypmnPayment;
	}

	protected function getReturnUrl($order)
	{
		$successUrl  = JURI::root() . 'index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_ypmn&order_id=' . $order->order_id;
		return $successUrl;
	}

	protected function getAuthorization()
	{
		$paymentMethodType = $this->pmconfigs['payment_method'];

		$isPaymentPage = false;

		if ($paymentMethodType === '') {
			$paymentMethodType = null;
		}


		if ($paymentMethodType === PaymentMethods::CCVISAMC) {
			$isPaymentPage = true;
		}

		$authorization = new Authorization($paymentMethodType, $isPaymentPage);
		return $authorization;
	}


	protected function getClient($order)
	{
		$billing = $this->getBilling($order);
		$client  = new Client();
		$client->setBilling($billing);
		$client->setCurrentClientIp();
		$client->setCurrentClientTime();
		return $client;
	}

	protected function getBilling($order)
	{
		$phone = $order->phone?:$order->mobile_phone;
		if (!$phone) {
			throw new \Exception(Text::_('COM_YPMN_JSHOP_NO_PHONE'));
		}
		$billing = new Billing();
		$billing->setFirstName($order->f_name);
		$billing->setLastName($order->l_name);
		$billing->setPhone($phone);
		$billing->setEmail($order->email);
		$billing->setCountryCode('RU');
		return $billing;
	}

	protected function getOrderProducts($order)
	{
		if (!$this->config->get('product_list')) {
			$item = [
				"name"      => Text::_('COM_YPMN_JSHOP_PRODUCT'),
				"sku"       => 'product',
				"quantity"  => 1,
				"unitPrice" => floatval($order->order_total),
				"vat"       => 1,
			];
			return [new Product($item)];
		}

		$products = [];

		$order->loadItemsNewDigitalProducts();
        $orderItems = $order->getAllItems();

        $configTax = $this->config->get('tax_id');

		foreach ($orderItems as $key => $item) {
			$tax = $configTax;
			if ($tax < 0) {
				$tax = $item->product_tax;
			}
			$item = [
				"name"      => $item->product_name,
				"sku"       => sprintf("%d.%s", $key, $item->product_ean),
				"quantity"  => intval($item->product_quantity),
				"unitPrice" => floatval($item->product_item_price),
				"vat"       => intval($tax),
			];
			$products[] = new Product($item);
		}


		$shipping        = false;
		$shippingModel   = JSFactory::getTable('shippingMethod', 'jshop');
		$shippingMethods = $shippingModel->getAllShippingMethodsCountry($order->d_country, $order->payment_method_id);
		foreach ($shippingMethods as $tmp) {
			if ($tmp->shipping_id == $order->shipping_method_id) {
				$shipping = $tmp;
			}
		}

		if ($order->order_payment > 0) {
			$item = [
				"name"      => Text::_('COM_YPMN_JSHOP_PAYMENT'),
				"sku"       => 'payment',
				"quantity"  => 1,
				"unitPrice" => floatval($order->order_payment),
				"vat"       => intval($this->config->get('tax_id')),
			];
			$products[] = new Product($item);
		}

		if ($order->shipping_method_id && $shipping && $shipping->shipping_stand_price) {
			$deliveryTax = $this->config->get('tax_id_delivery');
			if ($deliveryTax < 0) {
				$deliveryTax = $order->shipping_tax;
			}
			$item = [
				"name"      => $shipping->name,
				"sku"       => 'delivery',
				"quantity"  => 1,
				"unitPrice" => floatval($shipping->shipping_stand_price),
				"vat"       => intval($deliveryTax),
			];
			$products[] = new Product($item);
		}


		return $products;
	}

	public function getUrlParams($pmconfigs)
	{
		$data = file_get_contents("php://input");
		$data = json_decode($data, true);
		if (!$data) {
			return [];
		}
		list($orderId, ) = explode('.', $data['orderData']['merchantPaymentReference']);
		$params              = array();
		$params['order_id']  = $orderId;
		$params['hash']      = "";
		$params['checkHash'] = 0;
		return $params;
	}

	public function noCheckReturnExecute($checkout)
	{
		$lang = Factory::getLanguage();
		$extension = 'com_ypmn';
		$lang->load($extension);
		$body = Factory::getApplication()->input->get('body', null, 'RAW');
		$body = json_decode($body, true);
		if ($body && $body['status'] == 'SUCCESS') {
			$result = Text::_('COM_YPMN_ORDER_PAYED');
		} else {
			$result = Text::_('COM_YPMN_ORDER_ERROR');
		}

		Factory::getSession()->set("jshop_ypmn_result", $result);
	}
}
