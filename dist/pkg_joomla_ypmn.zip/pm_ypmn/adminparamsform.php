<?php
/**
 * @package    Your payments
 *
 * @copyright  Copyright (C) 2025  Your payments. All rights reserved.
 * @author     Your payments <info@ypmn.ru>
 * 			   20.07.25
 *
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;
?>

<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
<tr>
	<td class="key">
		<?php echo Text::_('COM_YMPN_PAYMENT_METHOD')?>
	</td>
	<td>
		<?php
echo HTMLHelper::_('select.genericlist', [
	[
		'id' => '',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_PAGE'),
	],
	[
		'id' => 'CCVISAMC',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_CCVISAMC'),
	],
	[
		'id' => 'FASTER_PAYMENTS',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_FASTER_PAYMENTS'),
	],
	[
		'id' => 'BNPL',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_BNPL'),
	],
	[
		'id' => 'SBERPAY',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_SBERPAY'),
	],
	[
		'id' => 'ALFAPAY',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_ALFAPAY'),
	],
	[
		'id' => 'TPAY',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_TPAY'),
	],
	[
		'id' => 'INTCARD',
		'name' => Text::_('COM_YMPN_PAYMENT_METHOD_SOM'),
	],
], 'pm_params[payment_method]', 'class = "inputbox custom-select" size = "1" style="max-width:240px; display: inline-block"', 'id', 'name', $params['payment_method']);
?>
	</td>
</tr>
<tr>
	<td class="key">
		<?php echo Text::_('JSHOP_TRANSACTION_PENDING')?>
	</td>
	<td>
		<?php
echo HTMLHelper::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_pending_status]', 'class = "inputbox custom-select" size = "1" style="max-width:240px; display: inline-block"', 'status_id', 'name', $params['transaction_pending_status']);
?>
	</td>
</tr>
<tr>
	<td class="key">
		<?php echo Text::_('JSHOP_TRANSACTION_END')?>
	</td>
	<td>
		<?php
echo HTMLHelper::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox custom-select" size = "1" style="max-width:240px; display: inline-block"', 'status_id', 'name', $params['transaction_end_status']);
?>
	</td>
</tr>
<tr>
	<td class="key">
		<?php echo Text::_('COM_YMPN_AUTHORIZATION_STATUS')?>
	</td>
	<td>
		<?php
echo HTMLHelper::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_confirm_status]', 'class = "inputbox custom-select" size = "1" style="max-width:240px; display: inline-block"', 'status_id', 'name', $params['transaction_confirm_status']);
?>
	</td>
</tr>
<tr>
	<td class="key">
		<?php echo Text::_('COM_YMPN_REFUND_STATUS')?>
	</td>
	<td>
		<?php
echo HTMLHelper::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_refunded_status]', 'class = "inputbox custom-select" size = "1" style="max-width:240px; display: inline-block"', 'status_id', 'name', $params['transaction_refunded_status']);
?>
	</td>
</tr>
</table>
</fieldset>
<p>
	<?php $callbackUrl = Uri::root() . "index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_ypmn&no_lang=1";?>
	<?php echo Text::sprintf('COM_YMPN_JSOP_ADDITIONAL', $callbackUrl)?>
</p>
</div>
<div class="clr"></div>